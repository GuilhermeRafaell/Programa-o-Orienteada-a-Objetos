import java.util.Scanner;

public class TesteContas {

	public static void main(String[] args) {
		
		ContaPoupanca[] c1 = new ContaPoupanca[5];
		Scanner readeScanner = new Scanner(System.in);
		
		for(int i=0; i<5; i++) {
			c1[i] = new ContaPoupanca(readeScanner.nextInt(), readeScanner.nextInt(), readeScanner.nextDouble(), readeScanner.nextDouble());
		}
		
		System.out.println("Saldo Conta Poupanca: " + c1[0].getSaldo());
		c1[0].sacar(50);
		
		System.out.println("Saldo depois do saque: " + c1[0].getSaldo());
		c1[0].calcularNovoSaldo();
		
		System.out.println("Saldo com a Taxa do rendimento mensal: " + c1[0].getSaldo());
				
		ContaEspecial[] c2 = new ContaEspecial[5];
		for(int i=0; i<5; i++) {
			c2[i] = new ContaEspecial(readeScanner.nextInt(), readeScanner.nextInt(), readeScanner.nextDouble(), readeScanner.nextDouble());
		}
		


		System.out.println("Saldo Conta Poupanca: " + c1[0].getSaldo());
		System.out.println("Saldo Conta Especial: " + c2[0].getSaldo());

	}

}
