
public class ContaEspecial extends ContaPoupanca{
	private double limite;
	
	public ContaEspecial() {
		
	}
	
	public ContaEspecial(int Cpf,int nroconta,double sal,double taxa) {
		setCpf(Cpf);
		setNumConta(nroconta);
		setSaldo(sal);
		setTaxarm(taxa);
	}

	public boolean sacar(float valor) {
		double aux = super.getSaldo();
		if(valor <= aux+limite){
			aux -= valor;
			return true;
		}
		else {
			return false;
		}
	
	}
}
