
public class ContaPoupanca {
		private int cpf;
		private int numConta;
		private double saldo;
		private double taxarm;
		
		public ContaPoupanca() {
			
		}
		
		public ContaPoupanca(int Cpf, int nroconta, double sal, double taxa) {
			setCpf(Cpf);
			setNumConta(nroconta);
			setSaldo(sal);
			setTaxarm(taxa);
		}
		
		public double getTaxarm() {
			return taxarm;
		}

		public void setTaxarm(double taxarm) {
			this.taxarm = taxarm;
		}

		public int getCpf() {
			return cpf;
		}
		public void setCpf(int cpf) {
			this.cpf = cpf;
		}
		
		public int getNumConta() {
			return numConta;
		}
		public void setNumConta(int numConta) {
			this.numConta = numConta;
		}
		
		public double getSaldo() {
			return saldo;
		}
		public void setSaldo(double saldo) {
			if(saldo >= 100)
				this.saldo = saldo;
		}
		
		public void depositar(double valor) {
			saldo += valor;
		}
		
		public boolean sacar(double valor) {
			if(valor <= saldo+100) {
				saldo -= valor;
				return true;
			}else{
				return false;
			}
			
		}
		
		public void calcularNovoSaldo() {
			taxarm += 1;
			saldo *= taxarm;
		}
		
		
		
	}
